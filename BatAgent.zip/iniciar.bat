@echo off 
color 09 
title BatAgent Server 
node server.js 
pause 
