const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const si = require('systeminformation');
const screenshot = require('screenshot-desktop');
const notifier = require('node-notifier');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3737;

// O BatComputer vai enviar esse token no header para garantir que ninguem fora a pagina legitima execute comandos
const BAT_TOKEN = 'WAYNE_ENTERPRISES_SUPREME_TOKEN';

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Middleware de seguranca local
app.use((req, res, next) => {
  const token = req.headers['authorization'];
  // Permite ping e OPTIONS sem token
  if (req.method === 'OPTIONS' || req.path === '/api/ping') return next();
  
  if (token !== `Bearer ${BAT_TOKEN}`) {
    return res.status(403).json({ error: 'Acesso Negado: Criptografia Kerberos Invalida' });
  }
  next();
});

// 1. Ping
app.get('/api/ping', (req, res) => {
  res.json({ status: 'online', message: 'BatAgent Operacional' });
});

// 2. Status do Sistema (CPU, RAM, Disco, Bateria)
app.get('/api/status', async (req, res) => {
  try {
    const [cpuInfo, mem, osInfo, battery] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.osInfo(),
      si.battery()
    ]);
    res.json({
      cpu: cpuInfo.currentLoad,
      ram: { used: mem.active, total: mem.total },
      uptime: osInfo.uptime,
      battery: battery.hasBattery ? battery.percent : null
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 3. Executar Comandos Powershell / Cmd
app.post('/api/run-cmd', (req, res) => {
  const { command } = req.body;
  if (!command) return res.status(400).json({ error: 'Nenhum comando recebido' });

  exec(`powershell -Command "${command.replace(/"/g, '\\"')}"`, (error, stdout, stderr) => {
    res.json({
      stdout: stdout ? stdout.trim() : '',
      stderr: stderr ? stderr.trim() : '',
      error: error ? error.message : null
    });
  });
});

// 4. Mandar Noficacao Windows
app.post('/api/notify', (req, res) => {
  const { title, message } = req.body;
  notifier.notify({
    title: title || 'BatComputer',
    message: message || 'Notificacao recebida.',
    icon: path.join(__dirname, '..', 'icons', 'icon-192.png'),
    sound: true
  });
  res.json({ success: true });
});

// 5. Screenshot da tela atual (Base64)
app.get('/api/screenshot', async (req, res) => {
  try {
    const imgBuffer = await screenshot({ format: 'jpg' });
    const b64 = imgBuffer.toString('base64');
    res.json({ image: `data:image/jpeg;base64,${b64}` });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao capturar tela: ' + e.message });
  }
});

// 6. Analise de processos rodando (resumido)
app.get('/api/processes', async (req, res) => {
  try {
    const processes = await si.processes();
    // pegamos so os principais pra nao sobrecarregar (ex: navegadores, IDEs, etc)
    const list = processes.list
      .filter(p => p.cpu > 0.5 || p.mem > 0.5)
      .slice(0, 15)
      .map(p => ({
        name: p.name,
        cpu: p.cpu.toFixed(1),
        mem: p.mem.toFixed(1)
      }));
    res.json({ processes: list });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`[BAT-AGENT] Servidor iniciado na porta ${PORT}`);
  console.log(`[BAT-AGENT] Aguardando comandos do BatComputer...`);
});
