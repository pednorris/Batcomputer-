@echo off
color 0A
echo ========================================================
echo        BAT-AGENT SUPREME - INSTALADOR (WAYNE TECH)
echo ========================================================
echo.
echo [1] Instalando dependencias do Node...
call npm install
echo.
echo [2] Dependencias instaladas!
echo.
echo Para rodar o agente localmente agora, de um duplo clique no script 'iniciar.bat' (que vamos criar).
echo.
echo echo @echo off ^> iniciar.bat
echo echo color 09 ^>^> iniciar.bat
echo echo title BatAgent Server ^>^> iniciar.bat
echo echo node server.js ^>^> iniciar.bat
echo echo pause ^>^> iniciar.bat
echo @echo off > iniciar.bat
echo color 09 >> iniciar.bat
echo title BatAgent Server >> iniciar.bat
echo node server.js >> iniciar.bat
echo pause >> iniciar.bat
echo.
echo [3] Script de 'iniciar.bat' criado com sucesso.
echo.
echo INSTALACAO COMPLETA! 
echo Pressione qualquer tecla para sair ou feche esta janela.
pause > nul
